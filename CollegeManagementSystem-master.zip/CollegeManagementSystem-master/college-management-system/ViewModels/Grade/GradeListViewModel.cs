﻿using System.Collections.Generic;

namespace CollegeManagementSystem.ViewModels.Grade
{
    public class GradeListViewModel
    {
        public List<GradeViewModel> Grades { get; set; }
    }
}