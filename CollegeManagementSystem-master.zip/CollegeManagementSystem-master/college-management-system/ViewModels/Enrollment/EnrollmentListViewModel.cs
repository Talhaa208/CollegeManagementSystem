﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CollegeManagementSystem.ViewModels.Enrollment
{
    public class EnrollmentListViewModel
    {
        public List<EnrollmentViewModel> Enrollments { get; set; }

    }
}