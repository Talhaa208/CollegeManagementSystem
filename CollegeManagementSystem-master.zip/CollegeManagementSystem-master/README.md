# CollegeManagementSystem
Appearence Architecture: 
 
ASP.NET MVC 5 ,SQL Server using Entity Framework 6,JavaScript,Bootstrap,Dependency Injection and LocalDB 



![image](https://user-images.githubusercontent.com/71450016/111911302-0c2d4700-8a76-11eb-957e-f449d8cc15ce.png)

 
![image](https://user-images.githubusercontent.com/71450016/111912150-6da2e500-8a79-11eb-9292-31f69386f84b.png)

![image](https://user-images.githubusercontent.com/71450016/111911385-7219ce80-8a76-11eb-9161-3b9d1437fcdf.png)

![image](https://user-images.githubusercontent.com/71450016/111912200-a8a51880-8a79-11eb-8031-66df623d8d90.png)
